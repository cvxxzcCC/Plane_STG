

import pygame
import random
import sys
import codecs
from pygame.locals import *

#设置游戏屏幕大小
screen_width = 640
screen_height = 480

#子弹类
class Bullet(pygame.sprite.Sprite):
    def __init__(self,bullet_img,init_pos):
        pygame.sprite.Sprite.__init__(self)
        self.image = bullet_img
        self.rect = self.image.get_rect()
        self.rect.midbottom = init_pos
        self.speed = 10

    def move(self):
        self.rect.top -= self.speed

#机体类
class Player(pygame.sprite.Sprite):
    def __init__(self,plane_img,player_rect,init_pos):
        pygame.sprite.Sprite.__init__(self)
        self.image = []
        for i in range(len(player_rect)):
            self.image.append(plane_img.subsurface(player_rect[i]).convert_alpha())
        self.rect = player_rect[0]
        self.rect.topleft = init_pos
        self.speed = 8
        self.bullets = pygame.sprite.Group()
        self.image_index = 0
        self.is_hit = False

    #发射子弹
    def shoot(self,bullet_img):
        bullet = Bullet(bullet_img , self.rect.midbottom)
        self.bullets.add(bullet)

    def moveUp(self):
        if self.rect.top <= 0:
            self.rect.top = 0
        else:
            self.rect.top -= self.speed

    def moveDown(self):
        if self.rect.top >= screen_height - self.rect.height:
            self.rect.top = screen_height - self.rect.height
        else:
            self.rect.top += self.speed

    def moveLeft(self):
        if self.rect.left <= 0:
            self.rect.left = 0
        else:
            self.rect.left -= self.speed

    def moveRight(self):
        if self.rect.left >= screen_width - self.rect.width:
            self.rect.left = screen_width - self.rect.width
        else:
            self.rect.left += self.speed

#敌机类
class Enemy(pygame.sprite.Sprite):
    def __init__(self,enemy_img,enemy_down_imgs,init_pos):
        pygame.sprite.Sprite.__init__(self)
        self.image = enemy_img
        self.rect = self.image.get_rect()
        self.rect.topleft = init_pos
        self.down_imgs = enemy_down_imgs
        self.speed = 2
        self.down_index = 0

    def move(self):
        self.rect.top += self.speed

def write_txt(context,srtim,path):
    f = codecs.open(path,srtim,'utf8')
    f.write(str(context))
    f.close()

def read_txt(path):
    with open(path,'r',encoding = 'utf8') as f:
        lines = f.readlines()
    return lines

#初始化pgame
pygame.init()
screen = pygame.display.set_mode((screen_width , screen_height))
pygame.display.set_caption('touhou stg')
#设置inco
ic_launcher = pygame.image.load('resource/1549385928242.jpg').convert_alpha()
pygame.display.set_icon(ic_launcher)
#加载背景图
background = pygame.image.load("resource/ui.png")
#游戏结束的图片
game_over = pygame.image.load("resource/1549385928242.jpg")
#机体，子弹，敌机
plane_img = pygame.image.load("resource/15-6.png")


def startGame():
    player_rect = []
    player_rect.append(pygame.Rect(0,0,96,128))
    player_rect.append(pygame.Rect(0, 0, 96, 128))
    #2
    player_rect.append(pygame.Rect(100, 100, 100, 100))
    player_rect.append(pygame.Rect(4, 0, 96, 128))
    player_rect.append(pygame.Rect(3, 0, 96, 128))
    player_rect.append(pygame.Rect(100, 200, 96, 128))

    player_pos = [300,300]
    player = Player(plane_img,player_rect,player_pos)

    bullet_rect = pygame.Rect(60,20,15,15)
    bullet_img = plane_img.subsurface(bullet_rect)


    enemyl_rect = pygame.Rect(96, 256, 96, 128)
    enemyl_img = plane_img.subsurface(enemyl_rect)

    enemyl_down_ims = []
    enemyl_down_ims.append(plane_img.subsurface(pygame.Rect(0, 128, 96, 128)))
    enemyl_down_ims.append(plane_img.subsurface(pygame.Rect(0, 256, 96, 128)))
    enemyl_down_ims.append(plane_img.subsurface(pygame.Rect(96, 128, 96, 128)))
    enemyl_down_ims.append(plane_img.subsurface(pygame.Rect(96, 256, 96, 128)))

    shoot_frequency = 0
    enemy_frequency = 0
    player_down_index = 16
    score = 0
    clock = pygame.time.Clock()

    enemiesl = pygame.sprite.Group()
    enemies_down = pygame.sprite.Group()


    running = True
    while running:
        screen.fill(0)
        screen.blit(background, (0, 0))
        clock.tick(60)
        #生成子弹
        if not player.is_hit:
            if shoot_frequency % 15 == 0:
                player.shoot(bullet_img)
            shoot_frequency += 1

            if shoot_frequency >= 15:
                shoot_frequency = 0

        for bullet in player.bullets:
            bullet.move()
            if bullet.rect.bottom < 0:
                player.bullets.remove(bullet)

        player.bullets.draw(screen)

        if enemy_frequency % 50 == 0:
            enemyl_pos = [random.randint(0,screen_width - enemyl_rect.width),0]
            enemyl = Enemy(enemyl_img,enemyl_down_ims,enemyl_pos)
            enemiesl.add(enemyl)

        enemy_frequency += 1

        if enemy_frequency >= 100:
            enemy_frequncy = 0

        for enemy in enemiesl:
            enemy.move()
            if enemy.rect.top < 0:
                enemiesl.remove(enemy)
            if pygame.sprite.collide_circle(enemy,player):
                enemies_down.add(enemy)
                enemiesl.remove(enemy)
                player.is_hit = True
                break

        if not player.is_hit:
            screen.blit(player.image[player.image_index],player.rect)
            player.image_index = shoot_frequency // 8

        else:
            player.image_index = player_down_index // 8
            screen.blit(player.image[player.image_index],player.rect)
            player_down_index += 1
            if player_down_index >47 :
                running = False

        enemiesl_down = pygame.sprite.groupcollide(enemiesl,player.bullets,True,1)

        for enemy_down in enemiesl_down:
            enemies_down.add(enemy_down)

        for enemy_down in enemies_down:
            if enemy_down.down_index > 7:
                enemies_down.remove(enemy_down)
                score += 100
                continue

            screen.blit(enemy_down.down_imgs[enemy_down.down_index // 2],enemy_down.rect)
            enemy_down.down_index += 1

        enemiesl.draw(screen)
        score_font = pygame.font.Font(None,36)
        score_text = score_font.render(str(score),True,(128,128,128))
        text_rect = score_text.get_rect()
        screen.blit(score_text,text_rect)

        # 自机
        if not player.is_hit:
            screen.blit(player.image[player.image_index], player.rect)

        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        key_pressed = pygame.key.get_pressed()

        if key_pressed[K_w] or key_pressed[K_UP]:
            player.moveUp()

        if key_pressed[K_s] or key_pressed[K_DOWN]:
            player.moveDown()

        if key_pressed[K_a] or key_pressed[K_LEFT]:
            player.moveLeft()

        if key_pressed[K_d] or key_pressed[K_RIGHT]:
            player.moveRight()

    screen.blit(game_over,(0,0))
    font = pygame.font.Font(None,48)
    text = font.render('Score:' + str(score),True,(255,0,0))
    text_rect = text.get_rect()
    text_rect.centerx = screen.get_rect().centerx
    text_rect.centery = screen.get_rect().centery + 24
    screen.blit(text,text_rect)

    xtfont = pygame.font.SysFont('SimHei',30)

    textstart = xtfont.render('排行榜',True,(255,0,0))
    text_rect = textstart.get_rect()
    text_rect.centerx = screen.get_rect().centerx
    text_rect.centery = screen.get_rect().centery + 130
    screen.blit(textstart,text_rect)


    textstart = xtfont.render('重新开始',True,(255,0,0))
    text_rect = textstart.get_rect()
    text_rect.centerx = screen.get_rect().centerx
    text_rect.centery = screen.get_rect().centery + 180
    screen.blit(textstart,text_rect)

    j = 0
    arrayscore = read_txt(r'score.txt')[0].split('mr')
    for i in range(0,len(arrayscore)):
        print(arrayscore)
        if score >int(arrayscore[i]):
            j = arrayscore[i]
            arrayscore[i] = str(score)
            score = 0
        if int(j) > int(arrayscore[i]):
            k = arrayscore[i]
            arrayscore[i] =str(j)
            j = k
    for i in range(0,len(arrayscore)):
        if i == 0:
            write_txt(arrayscore[i] + 'mr','w',r'score.txt')
        else:
            if(i == 9):
                write_txt(arrayscore[i] , 'a', r'score.txt')
            else:
                write_txt(arrayscore[i] + 'mr', 'a', r'score.txt')


startGame()

def gameranking():
    screen2 =pygame.display.set_mode((screen_width,screen_height))
    screen2.fill(0)
    screen2.blit(game_over,(0,0))

    xtfont = pygame.font.SysFont(('SimHei'),30)

    textstart = xtfont.render('排行榜',True,(255,0,0))
    text_rect = textstart.get_rect()
    text_rect.centerx = screen.get_rect().centerx
    text_rect.centery = 50
    screen2.blit(textstart,text_rect)

    textstart = xtfont.render('重新开始', True, (255, 0, 0))
    text_rect = textstart.get_rect()
    text_rect.centerx = screen.get_rect().centerx
    text_rect.centery = screen.get_rect().centery + 180
    screen2.blit(textstart, text_rect)

    arrayscore = read_txt(r'score.txt')[0].split('mr')
    for i in range(0,len(arrayscore)):
        font = pygame.font.Font(None,36)
        k = i + 1
        text = font.render(str(k) + ' ' + arrayscore[i],True,(255,0,0))
        text_rect = text.get_rect()
        text_rect.centerx = screen2.get_rect().centerx
        text_rect.centery = 60 + 30 * k
        screen2.blit(text,text_rect)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
           if (    screen.get_rect().centerx - 50 <= event.pos[0]
               and screen.get_rect().centerx + 50 >= event.pos[0]
               and screen.get_rect().centery + 100 <= event.pos[1]
               and screen.get_rect().centery + 140 >= event.pos[1]):
               gameranking()

           if (     screen.get_rect().centerx - 50 <= event.pos[0]
                and screen.get_rect().centerx + 50 >= event.pos[0]
                and screen.get_rect().centery + 160 <= event.pos[1]
                and screen.get_rect().centery + 190 >= event.pos[1]):
                startGame()

    pygame.display.update()